# Simple IPsec (AES Encryption + HMAC Integrity Check)

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
import hmac
import hashlib
import base64

# Shared secret keys (both sender & receiver must know)
aes_key = b"1234567890123456"       # 16 bytes = AES-128 key
hmac_key = b"hmacsecretkey123"      # HMAC key for integrity

# Original message
message = input("Enter message: ")
data = message.encode()

# -------- Sender side --------

# pad data to AES block size (16 bytes)
padder = padding.PKCS7(128).padder()
padded_data = padder.update(data) + padder.finalize()

# encrypt using AES (ECB mode, same as Java default "AES")
cipher = Cipher(algorithms.AES(aes_key), modes.ECB())
encryptor = cipher.encryptor()
encrypted = encryptor.update(padded_data) + encryptor.finalize()

# generate HMAC of encrypted data
mac = hmac.new(hmac_key, encrypted, hashlib.sha256).digest()

# print what gets "sent" over the network
print("Encrypted (Base64):", base64.b64encode(encrypted).decode())
print("HMAC (Base64):", base64.b64encode(mac).decode())

# -------- Receiver side --------

# recalculate HMAC on received data
hmac_check = hmac.new(hmac_key, encrypted, hashlib.sha256).digest()
