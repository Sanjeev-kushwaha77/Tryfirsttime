alphabet = "abcdefghijklmnopqrstuvwxyz"
key      = "zyxwvutsrqponmlkjihgfedcba"     # reverse alphabet

msg = input("Enter lowercase message: ").lower()

# Encrypt: replace each letter with corresponding key letter
enc = ""
for c in msg:
    if c == ' ':
        enc += ' '                          # keep spaces
    else:
        enc += key[alphabet.index(c)]       # find position, use key char

# Decrypt: reverse the process
dec = ""
for c in enc:
    if c == ' ':
        dec += ' '
    else:
        dec += alphabet[key.index(c)]       # find position in key, use alphabet

print("\n--- Substitution Cipher ---")
print("Original :", msg)
print("Encrypted:", enc)
print("Decrypted:", dec)
