# Practical 1: Substitution and Transposition Ciphers (no slicing used)

alphabet   = "abcdefghijklmnopqrstuvwxyz"
substitute = "zyxwvutsrqponmlkjihgfedcba"   # key: reverse alphabet

# substitution encryption
def substitution_encrypt(message):
    encrypted = ""
    for ch in message:
        if ch == " ":
            encrypted = encrypted + " "
        else:
            index = alphabet.index(ch)
            encrypted = encrypted + substitute[index]
    return encrypted

# substitution decryption
def substitution_decrypt(message):
    decrypted = ""
    for ch in message:
        if ch == " ":
            decrypted = decrypted + " "
        else:
            index = substitute.index(ch)
            decrypted = decrypted + alphabet[index]
    return decrypted

# transposition encryption (reverse string without slicing)
def transposition_encrypt(message):
    encrypted = ""
    index = len(message) - 1
    while index >= 0:
        encrypted = encrypted + message[index]
        index = index - 1
    return encrypted

# transposition decryption (reverse again)
def transposition_decrypt(message):
    decrypted = ""
    index = len(message) - 1
    while index >= 0:
        decrypted = decrypted + message[index]
        index = index - 1
    return decrypted

# main
message = input("Enter a lowercase message: ")
message = message.lower()

sub_encrypted = substitution_encrypt(message)
sub_decrypted = substitution_decrypt(sub_encrypted)

trans_encrypted = transposition_encrypt(message)
trans_decrypted = transposition_decrypt(trans_encrypted)

print("\n---- Substitution Cipher ----")
print("Encrypted:", sub_encrypted)
print("Decrypted:", sub_decrypted)

print("\n---- Transposition Cipher ----")
print("Encrypted:", trans_encrypted)
print("Decrypted:", trans_decrypted)
