# Diffie-Hellman Key Exchange (User Input Version)

# Step 1: Publicly agreed values
p = int(input("Enter a prime number (p): "))
g = int(input("Enter a primitive root modulo p (g): "))

print("\nPublicly known values:")
print("Prime (p):", p)
print("Primitive Root (g):", g)

# Step 2: Alice's keys
a = int(input("\nAlice, enter your private key (a): "))
A = pow(g, a, p)
print("Alice's private key (a):", a)
print("Alice's public key (A):", A)

# Step 3: Bob's keys
b = int(input("\nBob, enter your private key (b): "))
B = pow(g, b, p)
print("Bob's private key (b):", b)
print("Bob's public key (B):", B)

# Step 4 & 5: Shared secret
shared_key_alice = pow(B, a, p)
shared_key_bob   = pow(A, b, p)

print("\nAlice's computed shared key:", shared_key_alice)
print("Bob's computed shared key:", shared_key_bob)

# Verify
if shared_key_alice == shared_key_bob:
    print("\n Key exchange successful! Shared secret key established.")
else:
    print("\n Key exchange failed. Keys do not match.")
