# Digital Signature using RSA (SHA256withRSA equivalent)

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
import base64

# 1. Generate RSA key pair (public & private keys)
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key  = private_key.public_key()

# 2. Message
message = input("Enter message: ")
data = message.encode()

# 3. Sign the message with Private Key
signature = private_key.sign(
    data,
    padding.PKCS1v15(),
    hashes.SHA256()
)

# 4. Verify with Public Key
try:
    public_key.verify(
        signature,
        data,
        padding.PKCS1v15(),
        hashes.SHA256()
    )
    verified = True
except Exception:
    verified = False

# 5. Output
print("Original Message :", message)
print("Digital Signature:", base64.b64encode(signature).decode())
print("Signature Verified?", verified)
