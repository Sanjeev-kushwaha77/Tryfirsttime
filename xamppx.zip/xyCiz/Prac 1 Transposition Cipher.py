# Transposition Cipher

msg = input("Enter message: ")

# encrypt (reverse without slicing)
enc = ""
index = len(msg) - 1
while index >= 0:
    enc = enc + msg[index]
    index = index - 1

# decrypt (reverse again)
dec = ""
index = len(enc) - 1
while index >= 0:
    dec = dec + enc[index]
    index = index - 1

print("\n--- Transposition Cipher ---")
print("Original :", msg)
print("Encrypted:", enc)
print("Decrypted:", dec)
