import ssl
import socket

context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE   # For self-signed demo only

with socket.create_connection(('localhost', 8443)) as sock:
    with context.wrap_socket(sock, server_hostname='localhost') as ssock:
        print("Connected via:", ssock.version())
        ssock.sendall(b"Hello SSL Server\n")
        print("Server response:", ssock.recv(1024).decode().strip())