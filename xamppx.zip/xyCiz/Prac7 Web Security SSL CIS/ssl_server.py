import ssl
import socket

HOST, PORT = 'localhost', 8443
CERTFILE, KEYFILE = 'cert.pem', 'key.pem'

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(certfile=CERTFILE, keyfile=KEYFILE)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0) as sock:
    sock.bind((HOST, PORT))
    sock.listen(5)
    print(f"SSL server listening on port {PORT}")

    with context.wrap_socket(sock, server_side=True) as ssock:
        conn, addr = ssock.accept()
        print(f"Connection from {addr}")
        data = conn.recv(1024).decode()
        print(f"Received: {data.strip()}")
        conn.sendall(f"Server reply: Received '{data.strip()}'\n".encode())
        conn.close()